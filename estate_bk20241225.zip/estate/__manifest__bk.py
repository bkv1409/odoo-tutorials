# -*- coding: utf-8 -*-
{
    'name': "Real Estate",

    'summary': """
        Starting module for "Estate"
    """,

    'description': """
        Starting module for "Estate"
    """,

    'author': "VuNQ",
    'website': "https://www.odoo.com/",
    'category': 'Tutorials/Estate',
    'version': '0.1',
    'application': True,
    'installable': True,
    'depends': ['base'],

    'data': [],
    'license': 'AGPL-3'
}
